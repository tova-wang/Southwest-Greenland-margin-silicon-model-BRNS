#!/bin/sh -l 
#PBS -l walltime=72:00:00
#PBS -o testlogfile 
#PBS -e test.err 
#PBS -N test_Hazel

cd /home/stinkzwam/Hazel

./brns
